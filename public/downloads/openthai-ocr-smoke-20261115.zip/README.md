# OpenThai OCR Text synthetic smoke test

Measured on Apple M5 Max, CPUExecutionProvider, 2 threads.
Model revision: 40e8e9ff752b65153b1a71d521ec9390882afd7e
6 synthetic cases, 3 independent source pages, no real scanned corpus.
Each case measured 3 times after one warm-up on the notice.
Time excludes model download/load, source PDF rendering and image creation; includes image-file reading in LineOCR.read.
CER = Unicode NFC, whitespace removed, case-sensitive, using jiwer.cer (Unicode code points, not grapheme clusters).
Blank has CER null, output expected empty. No Markdown or Safari tests.

Reproduce: create Python 3.13 venv, install requirements-lock.txt, download iapp/OpenThai2.0-OCR-Text at the exact revision into model/.
Then run python evaluate.py. It expects macOS Google Chrome and Sarabun-Regular.ttf at the font path in the script.
The archive contains already-rendered images and exact reference texts, so inference can also be repeated on those images without regenerating HTML/PDF.
Generating figures is not OCR: the tested model received PNG pixels, never the PDF text layer.
Results are a single-session small synthetic smoke test, not a production accuracy claim.
