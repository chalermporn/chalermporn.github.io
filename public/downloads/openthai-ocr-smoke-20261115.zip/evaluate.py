"""Small synthetic OCR smoke test, not an independent benchmark corpus."""
from pathlib import Path
import sys, json, time, statistics, re, unicodedata, platform, subprocess, hashlib, html
from importlib.metadata import version
import pypdfium2 as pdfium
from PIL import Image, ImageFilter
from jiwer import cer

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'model'))
from runtime.line_engine import LineOCR

SAMPLES = [
    ('thai-notice', [
        'เอกสารตัวอย่างสำหรับทดสอบ OCR',
        'ประกาศการประชุมทีมงาน',
        'วันอาทิตย์ที่ 15 พฤศจิกายน 2569',
        'เวลา 09:30 น. ถึง 11:00 น.',
        'สถานที่ ห้องประชุมชั้น 2',
        'กรุณานำเอกสารฉบับเดิมมาด้วย',
        'ไม่อนุญาตให้เผยแพร่ข้อมูลภายนอก',
        'รายชื่อในเอกสารนี้เป็นข้อมูลสมมติ',
        'ผู้ประสานงาน สมชาย ใจดี',
        'หมายเลขอ้างอิง DOC-2026-001',
        'กรุณาตรวจสอบชื่อ วันที่ และตัวเลข',
    ]),
    ('mixed-invoice', [
        'ใบแจ้งยอดตัวอย่าง ไม่ใช่เอกสารซื้อขายจริง',
        'CodeMunha Document Test',
        'Invoice INV-2026-001',
        'วันที่ 15/11/2026',
        'จำนวนสินค้า 12 ชิ้น',
        'ราคาต่อหน่วย 125.50 บาท',
        'ยอดรวม 1,506.00 บาท',
        'ส่วนลด 50.00 บาท',
        'ยอดสุทธิ 1,456.00 บาท',
        'ยังไม่ได้ชำระเงิน',
        'Please verify the amount before payment.',
    ]),
    ('simple-table', [
        'ตารางตัวอย่างสำหรับทดสอบ',
        ['รายการ', 'จำนวน', 'ราคา'],
        ['กาแฟ', '2', '120.00'],
        ['ชาไทย', '3', '150.00'],
        ['น้ำเปล่า', '1', '15.00'],
        ['รวม', '6', '285.00'],
    ]),
]
ROOT.joinpath('inputs').mkdir(exist_ok=True)
font = Path('/Users/bird/Library/Fonts/Sarabun-Regular.ttf')
assert font.is_file()
sections=[]
for name, lines in SAMPLES:
    body=''
    for line in lines:
        if isinstance(line,list):
            body += '<div class="row">' + ''.join('<span>'+html.escape(s)+'</span>' for s in line) + '</div>'
        else:
            body += '<p>'+html.escape(line)+'</p>'
    sections.append('<section>'+body+'</section>')
source='''<!doctype html><meta charset="utf-8"><style>
@font-face{font-family:Sarabun;src:url("FONT_URI")}
@page{size:A4;margin:20mm}body{font-family:Sarabun;font-size:16pt;line-height:1.8;margin:0;color:#000;background:#fff}
p{margin:0 0 8pt}.row{display:grid;grid-template-columns:2fr 1fr 1fr;border-bottom:1px solid #bbb;padding:8pt 0}
section{break-after:page}section:last-child{break-after:auto}
</style>'''.replace('FONT_URI',font.as_uri()) + ''.join(sections)
(ROOT/'inputs/source.html').write_text(source)
chrome='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
subprocess.run([chrome,'--headless','--disable-gpu','--no-pdf-header-footer',
    '--allow-file-access-from-files','--run-all-compositor-stages-before-draw',
    '--user-data-dir='+str(ROOT/'chrome-profile'),'--print-to-pdf='+str(ROOT/'inputs/source.pdf'),
    (ROOT/'inputs/source.html').as_uri()],check=True,capture_output=True,timeout=60)
pdf=pdfium.PdfDocument(str(ROOT/'inputs/source.pdf'))
assert len(pdf)==3, len(pdf)
cases=[]
for i,(name,lines) in enumerate(SAMPLES):
    image=pdf[i].render(scale=200/72).to_pil().convert('RGB')
    text='\n'.join(' '.join(l) if isinstance(l,list) else l for l in lines)
    cases.append((name,image,text))
base=cases[0]
cases += [('notice-rotated-7deg',base[1].rotate(7,expand=True,fillcolor='white'),base[2]),
          ('notice-small-blurred',base[1].resize((827,1169)).filter(ImageFilter.GaussianBlur(0.8)),base[2]),
          ('blank',Image.new('RGB',base[1].size,'white'),'')]
def normalize(t):
    return re.sub(r'\s+','',unicodedata.normalize('NFC',t))
start=time.perf_counter()
ocr=LineOCR(str(ROOT/'model'),threads=2,runtime={'backend':'onnxruntime','precision':'fp32'})
load=time.perf_counter()-start
assert ocr.backend=='onnxruntime'
ocr.read(cases[0][1]) # one warm-up, excluded from warm measurements
rows=[]
for name,img,expected in cases:
    path=ROOT/'inputs'/f'{name}.png'; img.save(path)
    (ROOT/'inputs'/f'{name}.expected.txt').write_text(expected)
    times=[]; outputs=[]
    for _ in range(3):
        t=time.perf_counter(); result=ocr.read(str(path)); times.append(time.perf_counter()-t); outputs.append(result)
    predicted=outputs[0]['text']
    normalized_expected,normalized_prediction=normalize(expected),normalize(predicted)
    score=cer(normalized_expected,normalized_prediction) if normalized_expected else None
    critical=['15','09:30','11:00','DOC-2026-001','ไม่อนุญาต'] if name.startswith(('thai','notice')) else (['INV-2026-001','125.50','1,506.00','1,456.00','ยังไม่ได้ชำระเงิน'] if name=='mixed-invoice' else [])
    row={'id':name,'width':img.width,'height':img.height,'times_s':times,'median_s':statistics.median(times),
         'cer_remove_whitespace_nfc':score,'reference_chars':len(normalized_expected),
         'predicted':predicted,'expected':expected,'lines':len(result['lines']),
         'identical_across_3_runs':len({o['text'] for o in outputs})==1,
         'critical_checks':{k:k in predicted for k in critical},
         'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    (ROOT/f'{name}.result.json').write_text(json.dumps(row,ensure_ascii=False,indent=2))
    rows.append(row)
    print(json.dumps(row,ensure_ascii=False),flush=True)
assert rows[-1]['predicted'].strip()==''
report={'date':subprocess.check_output(['date','-Iseconds'],text=True).strip(),
    'hardware':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),
    'platform':platform.platform(),'python':platform.python_version(),'threads':2,'backend':ocr.backend,
    'providers':ocr.det.sess.get_providers(),'model_revision':'40e8e9ff752b65153b1a71d521ec9390882afd7e',
    'model_load_s':load,'warmup_count':1,'repeat_per_case':3,'synthetic':True,
    'dependencies':{n:version(n) for n in ['onnxruntime','numpy','pillow','opencv-python-headless','jiwer']},'cases':rows}
(ROOT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('COMPLETE',ROOT/'results.json',flush=True)
